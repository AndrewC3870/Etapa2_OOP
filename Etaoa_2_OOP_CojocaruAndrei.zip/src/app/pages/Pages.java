package app.pages;

public interface Pages {
    String printCurrentPage();

}
